local combat = Combat()
combat:setArea(createCombatArea({{1, 1, 1}, {1, 3, 1}, {1, 1, 1}})) -- Área de efeito ao redor do jogador

combat:setCallback(CALLBACK_PARAM_TARGETTILE, function(player, tile)
    if tile:getTopCreature() then
        local target = tile:getTopCreature()
        if target:isPlayer() or target:isMonster() then
            target:addHealth(-50) -- Dano de cada hit da magia
        end
    end
end)

local CHANNELING_DURATION = 1000 -- Tempo de canalização (ms)
local HITS_COUNT = 3 -- Número de hits
local HIT_INTERVAL = 1000 -- Intervalo entre cada hit (ms)

function onCastSpell(player)
    local startPosition = player:getPosition()

    -- Início da canalização
    player:say("Canalizando...", TALKTYPE_MONSTER_SAY)
    player:getPosition():sendMagicEffect(CONST_ME_MAGIC_BLUE)

    -- Verifica se o jogador se move durante a canalização
    addEvent(function()
        if player:getPosition() ~= startPosition then
            player:say("Canalização cancelada!", TALKTYPE_MONSTER_SAY)
            return
        end

        -- Execução dos 3 hits em área
        player:say("Magia ativada!", TALKTYPE_MONSTER_SAY)

        local function executeHit(hitNumber)
            if hitNumber > HITS_COUNT then
                return
            end

            if player:getPosition() ~= startPosition then
                player:say("Magia encerrada devido ao movimento!", TALKTYPE_MONSTER_SAY)
                return
            end

            -- Executa o efeito do hit atual
            combat:execute(player, player:getPosition())
            player:getPosition():sendMagicEffect(CONST_ME_EXPLOSIONHIT)

            -- Agendar o próximo hit
            addEvent(executeHit, HIT_INTERVAL, hitNumber + 1)
        end

        -- Inicia o primeiro hit
        executeHit(1)

    end, CHANNELING_DURATION)

    return 
end

spell:group("attack")
spell:id(148)
spell:name("gpt")
spell:words("gpt")
spell:castSound(SOUND_EFFECT_TYPE_SPELL_OR_RUNE)
spell:impactSound(SOUND_EFFECT_TYPE_SPELL_PHYSICAL_STRIKE)
spell:level(1)
spell:mana(25)
spell:isPremium(false)
spell:range(1)
spell:needCasterTargetOrDirection(true)
spell:blockWalls(true)
spell:cooldown(2 * 1000)
spell:groupCooldown(1 * 1000)
spell:needLearn(false)
spell:vocation(110, 111, 112, 113, 114, 120, 121, 122, 123, 124, 130, 131)
spell:register()

