local combat = Combat()
combat:setParameter(COMBAT_PARAM_TYPE, COMBAT_HAKIDAMAGE)
combat:setParameter(COMBAT_PARAM_EFFECT, CONST_ME_EXPLOSIONAREA)
combat:setParameter(COMBAT_PARAM_DISTANCEEFFECT, CONST_ANI_EXPLOSION)
combat:setParameter(COMBAT_PARAM_BLOCKARMOR, 1)

function onGetFormulaValues(player, level, skill, factor) 
	local fist = player:getSkillLevel(SKILL_FIST)
	local skillTotal = fist
	local levelTotal = player:getLevel() / 10
	return -(((skillTotal / 1.4) * (levelTotal / 2))) * 1.1, -((skillTotal / 1.2) * (levelTotal / 2.1)) * 1.2
	
end
combat:setCallback(CALLBACK_PARAM_SKILLFISTVALUE, "onGetFormulaValues")

local spell = Spell("instant")

function spell.onCastSpell(creature, var)
	return combat:execute(creature, var)
end

spell:group("attack")
spell:id(148)
spell:name("punch")
spell:words("punch")
spell:castSound(SOUND_EFFECT_TYPE_SPELL_OR_RUNE)
spell:impactSound(SOUND_EFFECT_TYPE_SPELL_PHYSICAL_STRIKE)
spell:level(1)
spell:mana(25)
spell:isPremium(false)
spell:range(1)
spell:needCasterTargetOrDirection(true)
spell:blockWalls(true)
spell:cooldown(2 * 1000)
spell:groupCooldown(1 * 1000)
spell:needLearn(false)
spell:vocation(110, 111, 112, 113, 114, 120, 121, 122, 123, 124, 130, 131)
spell:register()
