createFunctions(MonsterType) -- creates get/set functions for MonsterType
createFunctions(NpcType) -- creates get/set functions for NpcType
createFunctions(Spell) -- creates get/set functions for Spell
