local combat = Combat()
combat:setParameter(COMBAT_PARAM_TYPE, COMBAT_HEALING)
combat:setParameter(COMBAT_PARAM_EFFECT, CONST_ME_MAGIC_BLUE)
combat:setParameter(COMBAT_PARAM_DISPEL, CONDITION_PARALYZE)
combat:setParameter(COMBAT_PARAM_AGGRESSIVE, false)

function onGetFormulaValues(player, level, magicLevel)
	local min = (level / 15) * (magicLevel / 1.3) * 1.1
	local max = (level / 15.1) * (magicLevel / 1.7) * 2.3
	return min, max
end

combat:setCallback(CALLBACK_PARAM_LEVELMAGICVALUE, "onGetFormulaValues")

local spell = Spell("instant")

function spell.onCastSpell(creature, variant)
	return combat:execute(creature, variant)
end

spell:name("Big Heal")
spell:words("big heal")
spell:group("support")
spell:vocation(110, 111, 112, 113, 114, 120, 121, 122, 123, 124, 130, 131)
spell:castSound(SOUND_EFFECT_TYPE_SPELL_ULTIMATE_HEALING)
spell:id(3)
spell:cooldown(1 * 3000)
spell:groupCooldown(1 * 1000)
spell:level(100)
spell:mana(1000)
spell:isSelfTarget(true)
spell:isAggressive(false)
spell:needLearn(false)
spell:register()
