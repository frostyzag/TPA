-- Definindo a magia e parâmetros
local combat = Combat()
combat:setParameter(COMBAT_PARAM_TYPE, COMBAT_HAKIDAMAGE)  -- Tipo de dano Haki
combat:setParameter(COMBAT_PARAM_EFFECT, CONST_ME_EXPLOSIONAREA)  -- Efeito visual da magia
combat:setParameter(COMBAT_PARAM_DISTANCEEFFECT, CONST_ANI_EXPLOSION)  -- Efeito de animação da magia
combat:setParameter(COMBAT_PARAM_BLOCKARMOR, 1)  -- Considerar a armadura do alvo

-- Função para calcular os valores do dano com base no nível e habilidade
function onGetFormulaValues(player, level, skill, factor) 
    local fist = player:getSkillLevel(SKILL_FIST)  -- Obtém o nível de habilidade do jogador com socos (Fist)
    local skillTotal = fist  -- A habilidade de socos do jogador
    local levelTotal = player:getLevel() / 10  -- Fator de nível baseado no nível do jogador
    return -(((skillTotal / 1.4) * (levelTotal / 2))) * 1.1, -((skillTotal / 1.2) * (levelTotal / 2.1)) * 1.2
end
combat:setCallback(CALLBACK_PARAM_SKILLFISTVALUE, "onGetFormulaValues")  -- Chama a fórmula de cálculo quando a magia for lançada

-- Definindo a magia de "punch"
local spell = Spell("instant")

-- Função para executar a magia
function spell.onCastSpell(creature, var)
    return combat:execute(creature, var)  -- Executa o combate com os parâmetros definidos
end

-- Definições e propriedades da magia
spell:group("attack")  -- Define que é uma magia de ataque
spell:id(148)  -- ID da magia (pode ser ajustado)
spell:name("punch")  -- Nome da magia
spell:words("punch")  -- Palavra-chave para lançar a magia
spell:castSound(SOUND_EFFECT_TYPE_SPELL_OR_RUNE)  -- Som ao lançar a magia
spell:impactSound(SOUND_EFFECT_TYPE_SPELL_PHYSICAL_STRIKE)  -- Som do impacto
spell:level(1)  -- Nível necessário para usar a magia
spell:mana(25)  -- Mana necessária para lançar
spell:isPremium(false)  -- Define que não é necessário ser premium para usar
spell:range(1)  -- Distância de lançamento
spell:needCasterTargetOrDirection(true)  -- Necessário ter alvo ou direção para lançar
spell:blockWalls(true)  -- Magia pode atravessar paredes
spell:cooldown(2 * 1000)  -- Tempo de recarga (2 segundos)
spell:groupCooldown(1 * 1000)  -- Tempo de recarga do grupo
spell:needLearn(false)  -- Não é necessário aprender a magia
spell:vocation(110, 111, 112, 113, 114, 120, 121, 122, 123, 124, 130, 131)  -- Vocação que pode usar
spell:register()  -- Registra a magia no sistema
